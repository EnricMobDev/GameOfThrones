//
//  SummaryTableViewCell.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 29/05/2019.
//  Copyright © 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

class SummaryTableViewCell: UITableViewCell, GetCellIdentifierProtocol {

    @IBOutlet var containerView: UIView!
    
    // MARK: - Inbound Fligth
    @IBOutlet var inboundLabel: UILabel!
    
    @IBOutlet var inboundDepartureDateLabel: UILabel!
    @IBOutlet var inboundDepartureHourLabel: UILabel!
    
    @IBOutlet var inboundArrivalDateLabel: UILabel!
    @IBOutlet var inboundArrivalHourLabel: UILabel!
    
    // MARK: - Outbound Fligth
    @IBOutlet var outboundLabel: UILabel!
    
    @IBOutlet var outboundDepartureDateLabel: UILabel!
    @IBOutlet var outboundDepartureHourLabel: UILabel!
    
    @IBOutlet var outboundArrivalDateLabel: UILabel!
    @IBOutlet var outboundArrivalHourLabel: UILabel!
    
    // MARK: - Price
    @IBOutlet var priceLabel: UILabel!
}
