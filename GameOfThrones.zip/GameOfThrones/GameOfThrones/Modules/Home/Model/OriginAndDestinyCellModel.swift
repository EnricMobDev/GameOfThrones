//
//  OriginAndDestinyCellModel.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 27/05/2019.
//  Copyright © 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

struct OriginAndDestinyCellModel {
    var inbound: String
    var outbound: String
    var price: String
}
