//
//  HomePresenter.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 27/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

class HomePresenter: NSObject, HomeViewToPresenterProtocol, UITableViewDataSource {
    
    // MARK: - Variables
    var view: HomePresenterToViewProtocol?
    var interactor: HomePresenterToInteractorProtocol?
    var router: HomePresenterToRouterProtocol?
    
    var flights: [FlightsResponseModel] = []
    var fligthCells: [DrawerItemProtocol] = []
    
    // MARK: - Lifecycle
    func updateView() {
        view?.originTable.dataSource = self
        drawCells(fligths: flights)
    }
    
    func navigateToDestinationWith(originAndDestiny: OriginAndDestinyCellModel) {
        guard let viewController = view as? UIViewController else { return }
        router?.navigateToSumary(originViewController: viewController, originAndDestiny)
    }
    
    // MARK: - UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return fligthCells.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let item = fligthCells[indexPath.row]
        let drawer = item.cellDrawer
        
        let cell = drawer.tableView(tableView, cellForRowAt: indexPath)
        drawer.drawCell(cell, withItem: item)
        
        return cell
    }
}

extension HomePresenter: HomeInteractorToPresenterProtocol {
    
    func drawCells(fligths: [FlightsResponseModel]) {
        let bindedCells = bindToCellModel(fligths)
        let orderedCells = orderByPrice(bindedCells)
        let drawerCells = createDrawer(cells: orderedCells)
        addHeaderCellTo(drawerCells)
        
        DispatchQueue.main.async {
            self.view?.originTable.reloadData()
        }
    }
    
    // MARK: - Private funcs
    private func bindToCellModel(_ fligths: [FlightsResponseModel]) -> [OriginAndDestinyCellModel] {
        var fligthCells: [OriginAndDestinyCellModel] = []
        
        for flygth in fligths {
            guard let inboundOrigin = flygth.inboundOrigin, let outboundOrigin = flygth.outboundOrigin, let price = flygth.price else { return [] }
            fligthCells.append(OriginAndDestinyCellModel(inbound: inboundOrigin, outbound: outboundOrigin, price: price))
        }
        return fligthCells
    }
    
    private func orderByPrice(_ fligths: [OriginAndDestinyCellModel]) -> [OriginAndDestinyCellModel] {
        var orderedCells = fligths
        orderedCells.sort(by: { $0.price < $1.price && $0.outbound == $1.outbound} )
        return orderedCells
    }
    
    private func createDrawer(cells: [OriginAndDestinyCellModel]) -> [DrawerItemProtocol] {
        fligthCells = cells.map({ $0 })
        return fligthCells
    }
    
    private func addHeaderCellTo(_ fligths: [DrawerItemProtocol]) {

        let FIRST_POSITION = 0
        let headerCell = HeaderCellModel(title: Constants.header_origin_and_destiny_table)
        fligthCells.insert(headerCell, at: FIRST_POSITION)
    }
}
