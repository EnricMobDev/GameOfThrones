//
//  HomeProtocols.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 27/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

protocol HomePresenterToViewProtocol: class{
    func showSomething()
    var originTable: UITableView! {get set}
}

protocol HomeInteractorToPresenterProtocol: class{}

protocol HomePresenterToInteractorProtocol: class{
    var presenter: HomeInteractorToPresenterProtocol? {get set}
    func getAllExhanges()
}

protocol HomeViewToPresenterProtocol: class{
    var view: HomePresenterToViewProtocol? {get set}
    var interactor: HomePresenterToInteractorProtocol? {get set}
    var router: HomePresenterToRouterProtocol? {get set}
    func updateView()
    func navigateToDestinationWith(originAndDestiny: OriginAndDestinyCellModel)
    var flights: [FlightsResponseModel] {get set}
    var fligthCells: [DrawerItemProtocol] {get set}
}

protocol HomePresenterToRouterProtocol: class{
    static func createModule(flights: [FlightsResponseModel]) -> UIViewController
    func navigateToSumary(originViewController: UIViewController, _ originAndDestinyFlight: OriginAndDestinyCellModel)
}
