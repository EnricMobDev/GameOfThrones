//
//  HomeRouter.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 27/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

class HomeRouter: HomePresenterToRouterProtocol{
    
    class func createModule(flights: [FlightsResponseModel]) -> UIViewController{
        let view = HomeViewController()
        let presenter: HomeViewToPresenterProtocol & HomeInteractorToPresenterProtocol = HomePresenter()
        let interactor: HomePresenterToInteractorProtocol = HomeInteractor()
        let router: HomePresenterToRouterProtocol = HomeRouter()
        
        view.presenter = presenter
        presenter.flights = flights
        presenter.view = view
        presenter.router = router
        presenter.interactor = interactor
        interactor.presenter = presenter
        
        return view
    }
    
    func navigateToSumary(originViewController: UIViewController, _ originAndDestinyFlight: OriginAndDestinyCellModel) {
        originViewController.present(SummaryRouter.createModule(originAndDestinyFlight), animated: true)
    }
}
