//
//  HeaderOriginAndDestinyDrawer.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 28/05/2019.
//  Copyright © 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

final class HeaderOriginAndDestinyDrawer: CellDrawerProtocol {
    
    // MARK: - CellDrawerProtocol
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        tableView.register(UINib(nibName: HeaderTableViewCell.cellIdentifier(), bundle: nil), forCellReuseIdentifier: HeaderTableViewCell.cellIdentifier())
        
        return tableView.dequeueReusableCell(withIdentifier: HeaderTableViewCell.cellIdentifier(), for: indexPath)
    }
    
    func drawCell(_ cell: UITableViewCell, withItem item: Any) {
        
        guard let cell = cell as? HeaderTableViewCell,
            let item = item as? HeaderCellModel else { return }
        
        cell.selectionStyle = .none
        cell.headerTitle.text = item.title
    }
}

// MARK: - DrawerItemProtocol
extension HeaderCellModel: DrawerItemProtocol {
    
    var cellDrawer: CellDrawerProtocol {
        return HeaderOriginAndDestinyDrawer()
    }
}
