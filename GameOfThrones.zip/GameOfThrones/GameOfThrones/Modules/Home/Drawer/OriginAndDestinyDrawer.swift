//
//  OriginAndDestinyDrawer.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 27/05/2019.
//  Copyright © 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

internal final class OriginAndDestinyDrawer: CellDrawerProtocol {
    
    // MARK: - Constants
    private let BORDER_WIDTH_ONE : CGFloat = 1.0
    private let CORNERRADIUS: CGFloat = 10
    
    // MARK: - CellDrawerProtocol
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        tableView.register(UINib(nibName: OriginAndDestinationTableViewCell.cellIdentifier(), bundle: nil), forCellReuseIdentifier: OriginAndDestinationTableViewCell.cellIdentifier())
        
        return tableView.dequeueReusableCell(withIdentifier: OriginAndDestinationTableViewCell.cellIdentifier(), for: indexPath)
    }
    
    func drawCell(_ cell: UITableViewCell, withItem item: Any) {
        
        guard let cell = cell as? OriginAndDestinationTableViewCell,
            let item = item as? OriginAndDestinyCellModel else { return }
        
        cell.selectionStyle = .none
        cell.inboundLabel.text = item.inbound
        cell.outboundLabel.text = item.outbound
        cell.priceLabel.text = item.price
        drawCornerRadiusIn(cell: cell)
    }
    
    private func drawCornerRadiusIn(cell: OriginAndDestinationTableViewCell) {
        cell.containerView.layer.cornerRadius = CORNERRADIUS
        addBorderTo(cell: cell)
    }
    
    private func addBorderTo(cell: OriginAndDestinationTableViewCell) {
        cell.containerView.layer.borderWidth = BORDER_WIDTH_ONE
        cell.containerView.layer.borderColor = Constants.Colors.gray
    }
}

// MARK: - DrawerItemProtocol
extension OriginAndDestinyCellModel: DrawerItemProtocol {
    
    var cellDrawer: CellDrawerProtocol {
        return OriginAndDestinyDrawer()
    }
}
