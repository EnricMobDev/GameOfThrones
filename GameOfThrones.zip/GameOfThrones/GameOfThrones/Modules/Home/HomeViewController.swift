//
//  HomeViewController.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 27/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController, UITableViewDelegate {
    
    // MARK: - Variables
    var presenter: HomeViewToPresenterProtocol?
    
    // MARK: - Constants
    let HEADER_CELL = 0
    
    // MARK: - IBOutels
    @IBOutlet weak var originTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        originTable.delegate = self
        presenter?.updateView()
    }

    // MARK: - UITableViewDelegate
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if indexPath.row > HEADER_CELL {
            guard let departureCell = presenter?.fligthCells[indexPath.row] as? OriginAndDestinyCellModel else { return }
            presenter?.navigateToDestinationWith(originAndDestiny: departureCell)
        }
    }
}

extension HomeViewController: HomePresenterToViewProtocol {
    
    func showSomething() {}
}

