//
//  LaunchScreenEntities.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 31/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

struct LaunchScreenModel{
}
