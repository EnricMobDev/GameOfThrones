//
//  LaunchScreenRouter.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 31/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

class LaunchScreenRouter: LaunchScreenPresenterToRouterProtocol{
    
    class func createModule() -> UIViewController{
        let view = LaunchScreenViewController()
        let presenter: LaunchScreenViewToPresenterProtocol & LaunchScreenInteractorToPresenterProtocol = LaunchScreenPresenter()
        let interactor: LaunchScreenPresenterToInteractorProtocol = LaunchScreenInteractor()
        let router: LaunchScreenPresenterToRouterProtocol = LaunchScreenRouter()
        
        view.presenter = presenter
        presenter.view = view
        presenter.router = router
        presenter.interactor = interactor
        interactor.presenter = presenter
        
        return view
    }
    
    func navigateToHomeViewController(originViewController: UIViewController, _ flights: [FlightsResponseModel]) {
        originViewController.present(HomeRouter.createModule(flights: flights), animated: true)
    }
}
