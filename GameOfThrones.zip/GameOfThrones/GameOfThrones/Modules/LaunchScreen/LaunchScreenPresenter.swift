//
//  LaunchScreenPresenter.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 31/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

class LaunchScreenPresenter: LaunchScreenViewToPresenterProtocol {
    
    var view: LaunchScreenPresenterToViewProtocol?
    var interactor: LaunchScreenPresenterToInteractorProtocol?
    var router: LaunchScreenPresenterToRouterProtocol?
    
    func updateView() {
        interactor?.getAllExhanges()
    }
    
    // MARK: - Animation Methods
    func startAnimation() {
        UIView.animate(withDuration: 4.0,delay: 0, options: [.repeat, .autoreverse], animations: {
            self.view?.loadingImage.transform = CGAffineTransform(rotationAngle: (120.0 * .pi) / 120.0)
        })
    }
    
    func stopAnimation() {
        DispatchQueue.main.async {
            self.view?.loadingImage.layer.removeAllAnimations()
        }
    }
}

extension LaunchScreenPresenter: LaunchScreenInteractorToPresenterProtocol {
    
    func listOf(fligths: [FlightsResponseModel]) {
        sendFligthsToHomeViewController(fligths)
    }
    
    func sendFligthsToHomeViewController(_ flights: [FlightsResponseModel]) {
        guard let viewController = view as? UIViewController else { return }
        router?.navigateToHomeViewController(originViewController: viewController, flights)
        stopAnimation()
    }
}
