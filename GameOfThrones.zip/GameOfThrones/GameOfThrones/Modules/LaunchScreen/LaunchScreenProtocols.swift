//
//  LaunchScreenProtocols.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 31/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

protocol LaunchScreenPresenterToViewProtocol: class{
    func showSomething(argument: LaunchScreenModel)
    var loadingImage: UIImageView! {get set}
}

protocol LaunchScreenInteractorToPresenterProtocol: class{
    func listOf(fligths: [FlightsResponseModel])
}

protocol LaunchScreenPresenterToInteractorProtocol: class{
    var presenter: LaunchScreenInteractorToPresenterProtocol? {get set}
    func getAllExhanges()
}

protocol LaunchScreenViewToPresenterProtocol: class{
    var view: LaunchScreenPresenterToViewProtocol? {get set}
    var interactor: LaunchScreenPresenterToInteractorProtocol? {get set}
    var router: LaunchScreenPresenterToRouterProtocol? {get set}
    func updateView()
    func startAnimation()
}

protocol LaunchScreenPresenterToRouterProtocol: class{
    static func createModule() -> UIViewController
    func navigateToHomeViewController(originViewController: UIViewController, _ flights: [FlightsResponseModel])
}
