//
//  LaunchScreenViewController.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 31/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

class LaunchScreenViewController: UIViewController {
    
    var presenter: LaunchScreenViewToPresenterProtocol?
    
    @IBOutlet var loadingImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter?.updateView()
        presenter?.startAnimation()
    }
}

extension LaunchScreenViewController: LaunchScreenPresenterToViewProtocol {
    
    func showSomething(argument: LaunchScreenModel) {
    }
}
