//
//  SummaryPresenter.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 29/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

class SummaryPresenter: NSObject, SummaryViewToPresenterProtocol, UITableViewDataSource {
    
    var view: SummaryPresenterToViewProtocol?
    var interactor: SummaryPresenterToInteractorProtocol?
    var router: SummaryPresenterToRouterProtocol?
    
    var flightSelected: OriginAndDestinyCellModel?
    var summaryList: [DrawerItemProtocol] = []

    func updateView() {
        view?.summaryTable.dataSource = self
        interactor?.fetchSummaryOfTheFlights()
    }
    
    func recieveFlightList(_ flights: [FlightsResponseModel]) {
        let flights = bindToCellModel(flights)
        let filteredFlights = filterByUserSelection(flights)
        let cellsDrawed = createDrawer(cells: filteredFlights)
        addHeaderCellTo(cellsDrawed)
    }
    
    // MARK: - Private funcs
    private func bindToCellModel(_ flights: [FlightsResponseModel]) -> [SummaryCellModel] {
        var flightCells: [SummaryCellModel] = []
        
        for flight in flights {
            flightCells.append(SummaryCellModel(flight: flight))
        }
        return flightCells
    }
    
    private func filterByUserSelection(_ flights: [SummaryCellModel]) -> [SummaryCellModel] {
        
         return flights.filter({ $0.inbound == flightSelected?.inbound && $0.outbound == flightSelected?.outbound })
    }
    
    private func createDrawer(cells: [SummaryCellModel]) -> [DrawerItemProtocol] {
        summaryList = cells.map({ $0 })
        return summaryList
    }
    
    private func addHeaderCellTo(_ fligths: [DrawerItemProtocol]) {
        
        let FIRST_POSITION = 0
        let headerCell = HeaderCellModel(title: Constants.header_summary_table)
        summaryList.insert(headerCell, at: FIRST_POSITION)
    }
    
    // MARK: - UITableViewDataSource
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return summaryList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let item = summaryList[indexPath.row]
        let drawer = item.cellDrawer
        
        let cell = drawer.tableView(tableView, cellForRowAt: indexPath)
        drawer.drawCell(cell, withItem: item)
        
        return cell
    }
}

extension SummaryPresenter: SummaryInteractorToPresenterProtocol {
    
    func somethingFetched(argument: SummaryModel) {}
}
