//
//  SummaryCellModel.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 29/05/2019.
//  Copyright © 2019 Enric Pou Villanueva. All rights reserved.
//

import Foundation

struct SummaryCellModel {
    var inbound: String
    
    var inboundDepartureDate: String
    var inboundDepartureTime: String
    
    var inboundArrivalDate: String
    var inboundArrivalTime: String
    
    var outbound: String
    
    var outboundDepartureDate: String
    var outboundDepartureTime: String
    
    var outboundArrivalDate: String
    var outboundArrivalTime: String
    
    var price: String
    
    init(flight: FlightsResponseModel) {

        self.inbound = flight.inboundOrigin ?? ""
        self.inboundDepartureDate = flight.inboundDepartureDate ?? ""
        self.inboundDepartureTime = flight.inboundDepartureTime ?? ""
        self.inboundArrivalDate = flight.inboundArrivalDate ?? ""
        self.inboundArrivalTime = flight.inboundArrivalTime ?? ""

        self.outbound = flight.outboundOrigin ?? ""
        self.outboundDepartureDate = flight.outboundDepartureDate ?? ""
        self.outboundDepartureTime = flight.outboundDepartureTime ?? ""
        self.outboundArrivalDate = flight.outboundArrivalDate ?? ""
        self.outboundArrivalTime = flight.outboundArrivalTime ?? ""

        self.price = flight.price ?? ""
    }
}
