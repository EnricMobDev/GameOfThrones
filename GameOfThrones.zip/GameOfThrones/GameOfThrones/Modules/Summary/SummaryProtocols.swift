//
//  SummaryProtocols.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 29/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

protocol SummaryPresenterToViewProtocol: class{
    func showSomething(argument: SummaryModel)
    var summaryTable: UITableView! {get set}
}

protocol SummaryInteractorToPresenterProtocol: class{
    func somethingFetched(argument: SummaryModel)
    func recieveFlightList(_ fligths: [FlightsResponseModel])
}

protocol SummaryPresenterToInteractorProtocol: class{
    var presenter: SummaryInteractorToPresenterProtocol? {get set}
    func fetchSummaryOfTheFlights()
}

protocol SummaryViewToPresenterProtocol: class{
    var view: SummaryPresenterToViewProtocol? {get set}
    var interactor: SummaryPresenterToInteractorProtocol? {get set}
    var router: SummaryPresenterToRouterProtocol? {get set}
    func updateView()
    var flightSelected: OriginAndDestinyCellModel? {get set}
}

protocol SummaryPresenterToRouterProtocol: class{
    static func createModule(_ originAndDestinyFlight: OriginAndDestinyCellModel) -> UIViewController
}
