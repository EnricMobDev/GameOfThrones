//
//  SummaryDrawer.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 29/05/2019.
//  Copyright © 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

final class SummaryDrawer: CellDrawerProtocol {
    
    // MARK: - Constants
    private let BORDER_WIDTH_ONE : CGFloat = 1.0
    private let CORNERRADIUS: CGFloat = 10
    
    // MARK: - CellDrawerProtocol
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        tableView.register(UINib(nibName: SummaryTableViewCell.cellIdentifier(), bundle: nil), forCellReuseIdentifier: SummaryTableViewCell.cellIdentifier())
        
        return tableView.dequeueReusableCell(withIdentifier: SummaryTableViewCell.cellIdentifier(), for: indexPath)
    }
    
    func drawCell(_ cell: UITableViewCell, withItem item: Any) {
        
        guard let cell = cell as? SummaryTableViewCell,
            let item = item as? SummaryCellModel else { return }
        
        cell.selectionStyle = .none
        cell.inboundLabel.text = item.inbound
        
        cell.inboundDepartureDateLabel.text = item.inboundDepartureDate
        cell.inboundDepartureHourLabel.text = item.inboundDepartureTime
        
        cell.inboundArrivalDateLabel.text = item.inboundArrivalDate
        cell.inboundArrivalHourLabel.text = item.inboundArrivalTime
        
        cell.outboundLabel.text = item.outbound
        
        cell.outboundDepartureDateLabel.text = item.outboundDepartureDate
        cell.outboundDepartureHourLabel.text = item.outboundDepartureTime
        
        cell.outboundArrivalDateLabel.text = item.outboundArrivalDate
        cell.outboundArrivalHourLabel.text = item.outboundArrivalTime
        
        cell.priceLabel.text = item.price
        
        drawCornerRadiusIn(cell: cell)
    }
    
    private func drawCornerRadiusIn(cell: SummaryTableViewCell) {
        cell.containerView.layer.cornerRadius = CORNERRADIUS
        addBorderTo(cell: cell)
    }
    
    private func addBorderTo(cell: SummaryTableViewCell) {
        cell.containerView.layer.borderWidth = BORDER_WIDTH_ONE
        cell.containerView.layer.borderColor = Constants.Colors.gray
    }
}

// MARK: - DrawerItemProtocol
extension SummaryCellModel: DrawerItemProtocol {
    
    var cellDrawer: CellDrawerProtocol {
        return SummaryDrawer()
    }
}

