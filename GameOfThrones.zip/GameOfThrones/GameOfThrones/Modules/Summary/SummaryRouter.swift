//
//  SummaryRouter.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 29/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

class SummaryRouter: SummaryPresenterToRouterProtocol{
    
    class func createModule(_ originAndDestinyFlight: OriginAndDestinyCellModel) -> UIViewController{
        let view = SummaryViewController()
        let presenter: SummaryViewToPresenterProtocol & SummaryInteractorToPresenterProtocol = SummaryPresenter()
        let interactor: SummaryPresenterToInteractorProtocol = SummaryInteractor()
        let router: SummaryPresenterToRouterProtocol = SummaryRouter()
        
        view.presenter = presenter
        presenter.flightSelected = originAndDestinyFlight
        presenter.view = view
        presenter.router = router
        presenter.interactor = interactor
        interactor.presenter = presenter
        
        return view
    }
}
