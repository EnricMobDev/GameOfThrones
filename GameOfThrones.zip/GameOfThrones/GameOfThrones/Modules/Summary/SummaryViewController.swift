//
//  SummaryViewController.swift
//  GameOfThrones
//
//  Created by Enric Pou Villanueva on 29/05/2019.
//  Copyright (c) 2019 Enric Pou Villanueva. All rights reserved.
//

import UIKit

class SummaryViewController: UIViewController, UITableViewDelegate {
    
    var presenter: SummaryViewToPresenterProtocol?
    
    @IBOutlet var summaryTable: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        summaryTable.delegate = self        
        presenter?.updateView()
    }
}

extension SummaryViewController: SummaryPresenterToViewProtocol {
    
    func showSomething(argument: SummaryModel) {}
}
